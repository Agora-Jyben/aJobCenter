ESX = nil


TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

local lastPlayerSuccess = {}

RegisterNetEvent('esx_taxijob:success')
AddEventHandler('esx_taxijob:success', function()
	local xPlayer = ESX.GetPlayerFromId(source)
	local timeNow = os.clock()

    if not lastPlayerSuccess[source] or timeNow - lastPlayerSuccess[source] > 5 then
        lastPlayerSuccess[source] = timeNow

        math.randomseed(os.time())
        local total = math.random(CJobCenter.job.taxi.NPCJobEarnings.min, CJobCenter.job.taxi.NPCJobEarnings.max)


        xPlayer.addMoney(total)
        xPlayer.showNotification('vous avez gagné '..total.." $")
    end
end)