ESX = nil

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

local infolisens = {}

-- MySQL.ready(function()
-- 	MySQL.Async.fetchAll('SELECT * FROM user_licenses', {}, function(result)
--         for k,v in pairs(result) do
-- 			if v.type == "drive" then
-- 				for i=1 ,k, 1 do
-- 					table.insert(infolisens, {type = v.type, owner = v.owner})
-- 				end
-- 			end
--         end
--     end)
-- end)

local Plicence = false

RegisterNetEvent("JobCenter:giveitem")
AddEventHandler("JobCenter:giveitem", function(item)
    local src = source
    local xPlayer = ESX.GetPlayerFromId(src)
	local nbItem = math.random(1,5)

    xPlayer.addInventoryItem(item, nbItem)
	xPlayer.showNotification('vous avez ramasser ~b~'..nbItem.."~s~ morceau de Feraille")
end)

RegisterNetEvent("JobCenterLiv:giveitem")
AddEventHandler("JobCenterLiv:giveitem", function(item)
    local src = source
    local xPlayer = ESX.GetPlayerFromId(src)
	local nbItem = CJobCenter.job.livreur.NbItem

    xPlayer.addInventoryItem(item, nbItem)
	xPlayer.showNotification('vous avez ~b~'..nbItem.."~s~ commande à livrer !")
end)

RegisterNetEvent("JobCenter:venteitem")
AddEventHandler("JobCenter:venteitem", function(item)
    local src = source
    local xPlayer = ESX.GetPlayerFromId(src)
	local price = math.random(7,15)
	local nbItem = xPlayer.getInventoryItem(item).count
	local pricetotal = nbItem*price

    xPlayer.addMoney(pricetotal)
	xPlayer.removeInventoryItem(item, nbItem)
    xPlayer.showNotification('vous avez gagné ~g~'..pricetotal.." $")
end)

RegisterNetEvent("JobCenter:venteitemliv")
AddEventHandler("JobCenter:venteitemliv", function()
    local src = source
    local xPlayer = ESX.GetPlayerFromId(src)
	local price = math.random(7,15)
	local item = "livcommand"
	local nbItem = xPlayer.getInventoryItem(item).count

	if nbItem > 0 then
		xPlayer.addMoney(price)
		xPlayer.removeInventoryItem(item, 1)
		xPlayer.showNotification('vous avez gagné ~g~'..price.." $")
		TriggerClientEvent("aJobCenter:livsuivante")
	else 
		xPlayer.showNotification("Tu veux me carotte !? elle est ma commande !!!")
	end
end)

local Xpass

ESX.RegisterServerCallback("JobCenter:getLicencesPlayer", function(source, cb)
    local xPlayer = ESX.GetPlayerFromId(source)
	local idPlayer = xPlayer.identifier 

	MySQL.Async.fetchAll('SELECT * FROM user_licenses', {}, function(result)
        for k,v in pairs(result) do
			if v.type == "drive" then
				for i=1 ,k, 1 do
					table.insert(infolisens, {type = v.type, owner = v.owner})
				end
			end
        end
    end)
	
	for k,v in pairs(infolisens) do
		if v.owner == idPlayer then
			Xpass = true
		else
			Xpass = false
		end
	end
	return cb(Xpass)
end)