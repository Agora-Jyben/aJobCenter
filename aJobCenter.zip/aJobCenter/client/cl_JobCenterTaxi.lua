ESX = nil

local PlayerData = {}
local PermisTaxi 


TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)


RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
     PlayerData = xPlayer
end)

RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)  
	PlayerData.job = job  
	Citizen.Wait(5000) 
end)

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(10)
    end
    while ESX.GetPlayerData().job == nil do
		Citizen.Wait(10)
    end
    if ESX.IsPlayerLoaded() then

		ESX.PlayerData = ESX.GetPlayerData()

    end
end)


RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
	ESX.PlayerData = xPlayer
end)


RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)
	ESX.PlayerData.job = job
end)

RegisterNetEvent('esx:setJob2')
AddEventHandler('esx:setJob2', function(job2)
    ESX.PlayerData.job2 = job2
end)

local HasAlreadyEnteredMarker, OnJob, IsNearCustomer, CustomerIsEnteringVehicle, CustomerEnteredVehicle, IsDead, CurrentActionData = false, false, false, false, false, false, {}
local CurrentCustomer, CurrentCustomerBlip, DestinationBlip, targetCoords, LastZone, CurrentAction, CurrentActionMsg
local VetTaxi = false

function DrawSub(msg, time)
	ClearPrints()
	BeginTextCommandPrint('STRING')
	AddTextComponentSubstringPlayerName(msg)
	EndTextCommandPrint(time, 1)
end

function ShowLoadingPromt(msg, time, type)
	Citizen.CreateThread(function()
		Citizen.Wait(0)

		BeginTextCommandBusyspinnerOn('STRING')
		AddTextComponentSubstringPlayerName(msg)
		EndTextCommandBusyspinnerOn(type)
		Citizen.Wait(time)

		BusyspinnerOff()
	end)
end

function GetRandomWalkingNPC()
	local search = {}
	local peds   = ESX.Game.GetPeds()

	for i=1, #peds, 1 do
		if IsPedHuman(peds[i]) and IsPedWalking(peds[i]) and not IsPedAPlayer(peds[i]) then
			table.insert(search, peds[i])
		end
	end

	if #search > 0 then
		return search[GetRandomIntInRange(1, #search)]
	end

	for i=1, 250, 1 do
		local ped = GetRandomPedAtCoord(0.0, 0.0, 0.0, math.huge + 0.0, math.huge + 0.0, math.huge + 0.0, 26)

		if DoesEntityExist(ped) and IsPedHuman(ped) and IsPedWalking(ped) and not IsPedAPlayer(ped) then
			table.insert(search, ped)
		end
	end

	if #search > 0 then
		return search[GetRandomIntInRange(1, #search)]
	end
end

function ClearCurrentMission()
	if DoesBlipExist(CurrentCustomerBlip) then
		RemoveBlip(CurrentCustomerBlip)
	end

	if DoesBlipExist(DestinationBlip) then
		RemoveBlip(DestinationBlip)
	end

	CurrentCustomer           = nil
	CurrentCustomerBlip       = nil
	DestinationBlip           = nil
	IsNearCustomer            = false
	CustomerIsEnteringVehicle = false
	CustomerEnteredVehicle    = false
	targetCoords              = nil
end

function StartTaxiJob()
	ShowLoadingPromt(('prise de service : Taxi/Uber'), 5000, 3)
	ClearCurrentMission()

	OnJob = true
end

function StopTaxiJob()
	local playerPed = PlayerPedId()

	if IsPedInAnyVehicle(playerPed, false) and CurrentCustomer ~= nil then
		local vehicle = GetVehiclePedIsIn(playerPed,  false)
		TaskLeaveVehicle(CurrentCustomer,  vehicle,  0)

		if CustomerEnteredVehicle then
			TaskGoStraightToCoord(CurrentCustomer,  targetCoords.x,  targetCoords.y,  targetCoords.z,  1.0,  -1,  0.0,  0.0)
		end
	end

	ClearCurrentMission()
	OnJob = false
	DrawSub(('Mission terminée'), 5000)
end

function UniformTaxi()
    TriggerEvent('skinchanger:getSkin', function(skin)
        local uniformObject
        if skin.sex == 0 then
            uniformObject = CJobCenter.job.taxi.tenue.male
            VetTaxi = true
        else
            uniformObject = CJobCenter.job.taxi.tenue.female
            VetTaxi = true
        end
        if uniformObject then
            TriggerEvent('skinchanger:loadClothes', skin, uniformObject)
        end
    end)
end

function Tcivil()
    ESX.TriggerServerCallback('esx_skin:getPlayerSkin', function(skin, jobSkin)
        TriggerEvent('skinchanger:loadSkin', skin)
        VetTaxi = false
    end)
end

local MenuActif = false

Keys.Register('F6', 'Taxi', 'Ouvrir le menu Taxi', function()
	-- if ESX.PlayerData.job and ESX.PlayerData.job.name == 'unemployed' then
        if OnJob then
    	    MenuTaxiActif()
        end
	-- end
end)

function MenuTaxiActif()
    local MenuTaxiActif = RageUI.CreateMenu("~y~Taxi Job", "~y~Emploi Interimaire")
    MenuTaxiActif:SetRectangleBanner(0, 0, 0)

    
    RageUI.Visible(MenuTaxiActif, not RageUI.Visible(MenuTaxiActif))
    while MenuTaxiActif do
        Citizen.Wait(0)
        RageUI.IsVisible(MenuTaxiActif, true, false, true, function()
            --RageUI.Separator("")
            RageUI.Separator("~y~↓ Le Job ~y~↓")

            if OnJob == true then
                RageUI.ButtonWithStyle("~r~Arreter~s~ son service", nil, {RightLabel = "→"}, true, function(Hovered,Active,Selected)
                    if (Selected) then
                        StopTaxiJob()
                        RageUI.Popup{
                            message = "~y~[~b~Service-Info~y~]\n~r~Vous n'etes plus en service !"
                        }
                    end
                end)
            end

            end, function() 
            end)

        if not RageUI.Visible(MenuTaxiActif) then
            MenuTaxiActif = RMenu:DeleteType("MenuTaxiActif", true)
        end
    end
end
--------------------------------------------------------------------
function MenuTaxi()
    local menuTaxi = RageUI.CreateMenu("~y~Taxi Job", "~y~Emploi Interimaire")
    menuTaxi:SetRectangleBanner(0, 0, 0)

    
    RageUI.Visible(menuTaxi, not RageUI.Visible(menuTaxi))
    while menuTaxi do
        Citizen.Wait(0)
        RageUI.IsVisible(menuTaxi, true, false, true, function()
            --RageUI.Separator("")
			ESX.TriggerServerCallback("JobCenter:getLicencesPlayer", function(Xpass) 
				PermisTaxi = Xpass
			end)

			if PermisTaxi == true then
				RageUI.Separator("~y~↓ ~p~Le Vestiaire ~y~↓")

				if VetTaxi == false then
					RageUI.ButtonWithStyle("Prendre la tenue de ~o~service", nil, {RightLabel = "→"}, true, function(Hovered,Active,Selected)
						if (Selected) then
							UniformTaxi()
						end
					end)
				elseif VetTaxi == true then
					RageUI.ButtonWithStyle("Reprendre sa tenue ~g~Civil", nil, {RightLabel = "→"}, true, function(Hovered,Active,Selected)
						if (Selected) then
							Tcivil()
						end
					end)
				end

				RageUI.Separator("~y~↓ Le Job ~y~↓")

				if OnJob == true then
					RageUI.ButtonWithStyle("~r~Arreter~s~ son service", nil, {RightLabel = "→"}, true, function(Hovered,Active,Selected)
						if (Selected) then
							StopTaxiJob()
						end
					end)
				elseif OnJob == false then
					RageUI.ButtonWithStyle("~g~Prendre~s~ son service", nil, {RightLabel = "→"}, true, function(Hovered,Active,Selected)
						if (Selected) then
							StartTaxiJob()
							SpawnTaxi()
							RageUI.Popup{
								message = "~y~[~r~RAPPPEL~y~]\n~b~Appuyez sur ~r~F6~b~ pour arreter la recherche de client !"
							}
							MenuActif = true
						end
					end)
				end
			elseif PermisTaxi == false then
				RageUI.Popup{
					message = 'Vous devez avoir le permis de conduire pour ce job !'
				}
				PermisTaxi = nil
				RageUI.CloseAll()
			end

            end, function() 
            end)

        if not RageUI.Visible(menuTaxi) then
            menuTaxi = RMenu:DeleteType("menuTaxi", true)
        end
    end
end

function SpawnTaxi()
    local car = GetHashKey("taxi")

    RequestModel(car)
    while not HasModelLoaded(car) do
        RequestModel(car)
        Citizen.Wait(0)
    end

    local x, y, z = table.unpack(GetEntityCoords(GetPlayerPed(-1), false))
    local vehicle = CreateVehicle(car, CJobCenter.job.taxi.SpawnVeh.x, CJobCenter.job.taxi.SpawnVeh.y, CJobCenter.job.taxi.SpawnVeh.z, CJobCenter.job.taxi.SpawnVeh.h, true, false)
    SetEntityAsMissionEntity(vehicle, true, true)
    local plaque = "TAXI"..math.random(1,9)
    SetVehicleNumberPlateText(vehicle, plaque) 
    SetPedIntoVehicle(GetPlayerPed(-1),vehicle,-1)
    SetVehicleCustomPrimaryColour(vehicle, 255, 255, 0)
    SetVehicleCustomSecondaryColour(vehicle, 255, 255, 0)
    SetVehicleMaxMods(vehicle)
end

function SetVehicleMaxMods(vehicle)

    local props = {
      modEngine       = 2,
      modBrakes       = 2,
      modTransmission = 2,
      modSuspension   = 3,
      modTurbo        = true,
    }
  
    ESX.Game.SetVehicleProperties(vehicle, props)
  
end


--------------------------------------------------------------------
Citizen.CreateThread(function()
    while true do
        local Timer = 500
        local joueurs = GetEntityCoords(GetPlayerPed(-1), false)
        local distbossTaxi = Vdist(joueurs.x, joueurs.y, joueurs.z, CJobCenter.job.taxi.posped.boss.x, CJobCenter.job.taxi.posped.boss.y, CJobCenter.job.taxi.posped.boss.z)
        if distbossTaxi <= 5.0 and CJobCenter.jeveuxmarker then
            Timer = 5
            DrawMarker(20, CJobCenter.job.taxi.posped.boss.x, CJobCenter.job.taxi.posped.boss.y, CJobCenter.job.taxi.posped.boss.z-1, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.3, 0.3, 0.3, 255, 0, 0, 255, 0, 1, 2, 0, nil, nil, 0)
            if distbossTaxi <= 1.0 then
                Timer = 0
                RageUI.Text({ message = "~r~[E]~s~ pour parler au boss", time_display = 1 })
                if IsControlJustPressed(1,51) then
					MenuTaxi()
					-- if Permis == true then 
					-- 	-- RageUI.Popup{
					-- 	--     message = "J'ai pas le temps, revenez demain !"
					-- 	-- }
					-- 	MenuTaxi()
					-- 	RageUI.CloseAll()
					-- elseif Permis == false then 
					-- 	RageUI.Popup{
					-- 	    message = "Désoler mais il faut le permis de conduire pour ce job !"
					-- 	}
					-- end
                end   
            end
        end 

        local distdelTaxi = Vdist(joueurs.x, joueurs.y, joueurs.z, CJobCenter.job.taxi.DelVeh.x, CJobCenter.job.taxi.DelVeh.y, CJobCenter.job.taxi.DelVeh.z)
        if distdelTaxi <= 8.0 and CJobCenter.jeveuxmarker then
            Timer = 5
            DrawMarker(20, CJobCenter.job.taxi.DelVeh.x, CJobCenter.job.taxi.DelVeh.y, CJobCenter.job.taxi.DelVeh.z-1, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.3, 0.3, 0.3, 255, 0, 0, 255, 0, 1, 2, 0, nil, nil, 0)
            if distdelTaxi <= 1.0 then
                Timer = 0
                RageUI.Text({ message = "~r~[E]~s~ pour rendre le véhicule de fonction", time_display = 1 })
                if IsControlJustPressed(1,51) then
                    local veh,dist4 = ESX.Game.GetClosestVehicle(playerCoords)
                    if dist4 < 4 then
                        DeleteEntity(veh)
                        RageUI.Popup{
                            message = "Le véhicule a bien était rendu à l'entreprise !"
                        }
                        RageUI.CloseAll()
                    end
                end   
            end
        end 
        Citizen.Wait(Timer)   
    end
end)

Citizen.CreateThread(function()
	if CJobCenter.jeveuxblips then
        local blip = AddBlipForCoord(CJobCenter.job.taxi.posped.boss.x, CJobCenter.job.taxi.posped.boss.y, CJobCenter.job.taxi.posped.boss.z)

        SetBlipSprite (blip, 198)
        SetBlipDisplay(blip, 4)
        SetBlipScale  (blip, 0.7)
        SetBlipColour (blip, 5)
        SetBlipAsShortRange(blip, true)

        BeginTextCommandSetBlipName('STRING')
        AddTextComponentSubstringPlayerName('Taxi')
        EndTextCommandSetBlipName(blip)
	end
end)

-- Taxi Job
Citizen.CreateThread(function()
	while true do

		Citizen.Wait(0)
		local playerPed = PlayerPedId()

		if OnJob then
			if CurrentCustomer == nil then
				DrawSub(('conduisez à la recherche de ~y~passagers'), 5000)

				if IsPedInAnyVehicle(playerPed, false) and GetEntitySpeed(playerPed) > 0 then
					local waitUntil = GetGameTimer() + GetRandomIntInRange(30000, 45000)

					while OnJob and waitUntil > GetGameTimer() do
						Citizen.Wait(0)
					end

					if OnJob and IsPedInAnyVehicle(playerPed, false) and GetEntitySpeed(playerPed) > 0 then
						CurrentCustomer = GetRandomWalkingNPC()

						if CurrentCustomer ~= nil then
							CurrentCustomerBlip = AddBlipForEntity(CurrentCustomer)

							SetBlipAsFriendly(CurrentCustomerBlip, true)
							SetBlipColour(CurrentCustomerBlip, 2)
							SetBlipCategory(CurrentCustomerBlip, 3)
							SetBlipRoute(CurrentCustomerBlip, true)

							SetEntityAsMissionEntity(CurrentCustomer, true, false)
							ClearPedTasksImmediately(CurrentCustomer)
							SetBlockingOfNonTemporaryEvents(CurrentCustomer, true)

							local standTime = GetRandomIntInRange(60000, 180000)
							TaskStandStill(CurrentCustomer, standTime)

							ESX.ShowNotification('vous avez ~g~trouvé~s~ un client, conduisez jusqu\'à ce dernier')
						end
					end
				end
			else
				if IsPedFatallyInjured(CurrentCustomer) then
					ESX.ShowNotification('votre client est à pris un autre taxi. Cherchez-en un autre.')

					if DoesBlipExist(CurrentCustomerBlip) then
						RemoveBlip(CurrentCustomerBlip)
					end

					if DoesBlipExist(DestinationBlip) then
						RemoveBlip(DestinationBlip)
					end

					SetEntityAsMissionEntity(CurrentCustomer, false, true)

					CurrentCustomer, CurrentCustomerBlip, DestinationBlip, IsNearCustomer, CustomerIsEnteringVehicle, CustomerEnteredVehicle, targetCoords = nil, nil, nil, false, false, false, nil
				end

				if IsPedInAnyVehicle(playerPed, false) then
					local vehicle          = GetVehiclePedIsIn(playerPed, false)
					local playerCoords     = GetEntityCoords(playerPed)
					local customerCoords   = GetEntityCoords(CurrentCustomer)
					local customerDistance = #(playerCoords - customerCoords)

					if IsPedSittingInVehicle(CurrentCustomer, vehicle) then
						if CustomerEnteredVehicle then
							local targetDistance = #(playerCoords - targetCoords)

							if targetDistance <= 10.0 then
								TaskLeaveVehicle(CurrentCustomer, vehicle, 0)

								ESX.ShowNotification('vous êtes ~g~arrivé~s~ à destination')

								TaskGoStraightToCoord(CurrentCustomer, targetCoords.x, targetCoords.y, targetCoords.z, 1.0, -1, 0.0, 0.0)
								SetEntityAsMissionEntity(CurrentCustomer, false, true)
								TriggerServerEvent('esx_taxijob:success')
								RemoveBlip(DestinationBlip)

								local scope = function(customer)
									ESX.SetTimeout(60000, function()
										DeletePed(customer)
									end)
								end

								scope(CurrentCustomer)

								CurrentCustomer, CurrentCustomerBlip, DestinationBlip, IsNearCustomer, CustomerIsEnteringVehicle, CustomerEnteredVehicle, targetCoords = nil, nil, nil, false, false, false, nil
							end

							if targetCoords then
								DrawMarker(36, targetCoords.x, targetCoords.y, targetCoords.z + 1.1, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0, 234, 223, 72, 155, false, false, 2, true, nil, nil, false)
							end
						else
							RemoveBlip(CurrentCustomerBlip)
							CurrentCustomerBlip = nil
							targetCoords = CJobCenter.job.taxi.JobLocations[GetRandomIntInRange(1, #CJobCenter.job.taxi.JobLocations)]
							local distance = #(playerCoords - targetCoords)
							while distance < CJobCenter.job.taxi.MinimumDistance do
								Citizen.Wait(5)

								targetCoords = CJobCenter.job.taxi.JobLocations[GetRandomIntInRange(1, #CJobCenter.job.taxi.JobLocations)]
								distance = #(playerCoords - targetCoords)
							end

							local street = table.pack(GetStreetNameAtCoord(targetCoords.x, targetCoords.y, targetCoords.z))
							local msg    = nil

							if street[2] ~= 0 and street[2] ~= nil then
								msg = ('~s~Emmenez-moi à~y~ %s~s~, près de~y~ %s'):format(GetStreetNameFromHashKey(street[1]), GetStreetNameFromHashKey(street[2]))
							else
								msg = ('~s~Emmenez-moi à~y~ %s'):format(GetStreetNameFromHashKey(street[1]))
							end

							ESX.ShowNotification(msg)

							DestinationBlip = AddBlipForCoord(targetCoords.x, targetCoords.y, targetCoords.z)

							BeginTextCommandSetBlipName('STRING')
							AddTextComponentSubstringPlayerName('Destination')
							EndTextCommandSetBlipName(blip)
							SetBlipRoute(DestinationBlip, true)

							CustomerEnteredVehicle = true
						end
					else
						DrawMarker(36, customerCoords.x, customerCoords.y, customerCoords.z + 1.1, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0, 234, 223, 72, 155, false, false, 2, true, nil, nil, false)

						if not CustomerEnteredVehicle then
							if customerDistance <= 40.0 then

								if not IsNearCustomer then
									ESX.ShowNotification('vous êtes à proximité du client, approchez-vous de lui')
									IsNearCustomer = true
								end

							end

							if customerDistance <= 20.0 then
								if not CustomerIsEnteringVehicle then
									ClearPedTasksImmediately(CurrentCustomer)

									local maxSeats, freeSeat = GetVehicleMaxNumberOfPassengers(vehicle)

									for i=maxSeats - 1, 0, -1 do
										if IsVehicleSeatFree(vehicle, i) then
											freeSeat = i
											break
										end
									end

									if freeSeat then
										TaskEnterVehicle(CurrentCustomer, vehicle, -1, freeSeat, 2.0, 0)
										CustomerIsEnteringVehicle = true
									end
								end
							end
						end
					end
				else
					DrawSub(('veuillez remonter dans votre véhicule pour continuer la mission'), 5000)
				end
			end
		else
			Citizen.Wait(500)
		end
	end
end)

function IsInAuthorizedVehicle()
	local playerPed = PlayerPedId()
	local vehModel  = GetEntityModel(GetVehiclePedIsIn(playerPed, false))

    if vehModel == GetHashKey('taxi') then
        return true
    end
	
	return false
end



AddEventHandler('esx:onPlayerDeath', function()
	IsDead = true
end)

AddEventHandler('esx:onPlayerSpawn', function(spawn)
	IsDead = false
end)

Citizen.CreateThread(function()
    local hash = GetHashKey("u_m_o_finguru_01")
    while not HasModelLoaded(hash) do
        RequestModel(hash)
        Wait(20)
    end
    pedacceuilppa = CreatePed("PED_TYPE_CIVFEMALE", "u_m_o_finguru_01", CJobCenter.job.taxi.posped.ped.x, CJobCenter.job.taxi.posped.ped.y, CJobCenter.job.taxi.posped.ped.z-1, CJobCenter.job.taxi.posped.ped.h, false, true)
    SetBlockingOfNonTemporaryEvents(pedacceuilppa, true)
    FreezeEntityPosition(pedacceuilppa, true)
    SetEntityInvincible(pedacceuilppa, true)
    TaskStartScenarioInPlace(pedacceuilppa, 'WORLD_HUMAN_AA_COFFEE', 0, false)
end)