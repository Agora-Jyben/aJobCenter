Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(10)
    end
    while ESX.GetPlayerData().job == nil do
		Citizen.Wait(10)
    end
    if ESX.IsPlayerLoaded() then

		ESX.PlayerData = ESX.GetPlayerData()
        BlipsJob()
    end
end)

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
	ESX.PlayerData = xPlayer
	BlipsJob()
end)


RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)
	ESX.PlayerData.job = job
	BlipsJob()
end)

local inWork = false
local state = 0
local SetStateWaypoint = false
local pointfinal = false
    
function BlipsJob()
    Citizen.CreateThread(function()
        -- if ESX.PlayerData.job and ESX.PlayerData.job.name == 'ferrailleur' then
        local ferraillemap = AddBlipForCoord(CJobCenter.job.Feraille.PedPos.x, CJobCenter.job.Feraille.PedPos.y, CJobCenter.job.Feraille.PedPos.z)

        SetBlipSprite(ferraillemap, 566)
        SetBlipColour(ferraillemap, 40)
        SetBlipScale(ferraillemap, 0.65)
        SetBlipAsShortRange(ferraillemap, true)
        BeginTextCommandSetBlipName('STRING')
        AddTextComponentString("Ferrailleur")
        EndTextCommandSetBlipName(ferraillemap)
    -- end
    end)
end

CreateThread(function()
    ---------------------- PED ------------------------
    local Spawnpedname = GetHashKey(CJobCenter.job.Feraille.ped)
    while not HasModelLoaded(Spawnpedname) do
        RequestModel(Spawnpedname)
        Wait(60)
    end
    local Spawnpos = vector3(CJobCenter.job.Feraille.PedPos.x,CJobCenter.job.Feraille.PedPos.y,CJobCenter.job.Feraille.PedPos.z - 1)
    local heading = CJobCenter.job.Feraille.PedHeading

    local Spawnped = CreatePed(9, Spawnpedname, Spawnpos, heading, false, false)

    SetEntityInvincible(Spawnped, true)
    SetBlockingOfNonTemporaryEvents(Spawnped, true)
    FreezeEntityPosition(Spawnped, true)

    --CJobCenter.job.Feraille.posped.ped.x,CJobCenter.job.Feraille.posped.ped.y,CJobCenter.job.Feraille.posped.ped.z

    local SpawnpedFVente = GetHashKey(CJobCenter.job.Feraille.ped)
    while not HasModelLoaded(SpawnpedFVente) do
        RequestModel(SpawnpedFVente)
        Wait(60)
    end
    local SpawnposFVente = vector3(CJobCenter.job.Feraille.posped.ped.x,CJobCenter.job.Feraille.posped.ped.y,CJobCenter.job.Feraille.posped.ped.z - 1)
    local headingFVente = CJobCenter.job.Feraille.posped.ped.h

    local SpawnpedVenteF = CreatePed(9, SpawnpedFVente, SpawnposFVente, headingFVente, false, false)

    SetEntityInvincible(SpawnpedVenteF, true)
    SetBlockingOfNonTemporaryEvents(SpawnpedVenteF, true)
    FreezeEntityPosition(SpawnpedVenteF, true)

---------------------- Actions Ped ------------------------
    
   
    while true do
        local interval = 1000
        -- if ESX.PlayerData.job and ESX.PlayerData.job.name == 'ferrailleur' then
            if not inWork then
            
                pos = GetEntityCoords(PlayerPedId())
                distance = GetDistanceBetweenCoords(pos, vector3(CJobCenter.job.Feraille.PedPos.x,CJobCenter.job.Feraille.PedPos.y,CJobCenter.job.Feraille.PedPos.z - 1), true)
                
                if distance < 2 then
                    interval = 1
                    DrawScreenText("[~g~E~s~] Pour commencer une tournée",1)
                    if IsControlJustReleased(0, 51) then
                        -- inWork = true
                        -- Trajet()
                        MenuFerailleur()
                    end
                else
                    interval = 200
                end

                distanceVf = GetDistanceBetweenCoords(pos, vector3(CJobCenter.job.Feraille.posped.ped.x,CJobCenter.job.Feraille.posped.ped.y,CJobCenter.job.Feraille.posped.ped.z-1), true)
        
                if distanceVf < 2 then
                    interval = 1
                    DrawScreenText("[~g~E~s~] Pour vendre votre tournée",1)
                    if IsControlJustReleased(0, 51) then
                        -- inWork = true
                        -- Trajet()
                        -- MenuVenteFerailleur()
                        TriggerServerEvent("JobCenter:venteitem", "ferraille")
                    end
                else
                    interval = 200
                end
            end
        -- end
        Citizen.Wait(interval)
    end

end) 

local VetFeraille = false
local OnJobFeraille = false

MenuFerailleur = function()
    local MenuFerailleur = RageUI.CreateMenu("~r~Ferrailleur Job", "~y~Emploi Interimaire")
    MenuFerailleur:SetRectangleBanner(0, 0, 0)

    
    RageUI.Visible(MenuFerailleur, not RageUI.Visible(MenuFerailleur))

    while MenuFerailleur do
        Citizen.Wait(0)
        RageUI.IsVisible(MenuFerailleur, true, false, true, function()
            --RageUI.Separator("")

            RageUI.Separator("~y~↓ ~p~Le Vestiaire ~y~↓")

            if VetFeraille == false then
                RageUI.ButtonWithStyle("Prendre la tenue de ~o~service", nil, {RightLabel = "→"}, true, function(Hovered,Active,Selected)
                    if (Selected) then
                        UniformFeraille()
                    end
                end)
            elseif VetFeraille == true then
                RageUI.ButtonWithStyle("Reprendre sa tenue ~g~Civil", nil, {RightLabel = "→"}, true, function(Hovered,Active,Selected)
                    if (Selected) then
                        Tcivil()
                    end
                end)
            end

            RageUI.Separator("~y~↓ Le Job ~y~↓")

            if OnJobFeraille == true then
                RageUI.ButtonWithStyle("~r~Arreter~s~ son service", nil, {RightLabel = "→"}, true, function(Hovered,Active,Selected)
                    if (Selected) then
                        OnJobFeraille = false
                        inWork = false
                    end
                end)
            elseif OnJobFeraille == false then
                RageUI.ButtonWithStyle("~g~Prendre~s~ son service", nil, {RightLabel = "→"}, true, function(Hovered,Active,Selected)
                    if (Selected) then
                        inWork = true
                        TrajetFeraille()
                        OnJobFeraille = true
                    end
                end)
            end

            end, function() 
            end)

        if not RageUI.Visible(MenuFerailleur) then
            MenuFerailleur = RMenu:DeleteType("MenuFerailleur", true)
        end
    end
end

UniformFeraille = function()
    TriggerEvent('skinchanger:getSkin', function(skin)
        local uniformObject
        if skin.sex == 0 then
            uniformObject = CJobCenter.job.Feraille.tenue.male
            VetFeraille = true
        else
            uniformObject = CJobCenter.job.Feraille.tenue.female
            VetFeraille = true
        end
        if uniformObject then
            TriggerEvent('skinchanger:loadClothes', skin, uniformObject)
        end
    end)
end

Tcivil = function()
    ESX.TriggerServerCallback('esx_skin:getPlayerSkin', function(skin, jobSkin)
        TriggerEvent('skinchanger:loadSkin', skin)
        VetFeraille = false
    end)
end

function SetWaypoint()
    if state + 1 <= #CJobCenter.job.Feraille.state then
        blip = AddBlipForCoord(CJobCenter.job.Feraille.state[state + 1].x,CJobCenter.job.Feraille.state[state + 1].y,CJobCenter.job.Feraille.state[state + 1].z)
        SetBlipSprite(blip, CJobCenter.job.Feraille.blip)
        SetBlipColour(blip, CJobCenter.job.Feraille.blip_color)
        SetStateWaypoint = true
    else
        blip = AddBlipForCoord(CJobCenter.job.Feraille.posped.ped.x,CJobCenter.job.Feraille.posped.ped.y,CJobCenter.job.Feraille.posped.ped.z)
        SetBlipSprite(blip, 38)
        SetBlipColour(blip, 1)
        SetStateWaypoint = true
        pointfinal = true
    end
end

function FutWaypoint()
    RemoveBlip(blip)
    state = state + 1
    SetStateWaypoint = false
end



TrajetFeraille = function()
    while inWork do 
        local interval = 500
        local pos = GetEntityCoords(PlayerPedId())
        if state + 1 <= #CJobCenter.job.Feraille.state  then
            dest = vector3(CJobCenter.job.Feraille.state[state + 1].x,CJobCenter.job.Feraille.state[state + 1].y,CJobCenter.job.Feraille.state[state + 1].z)
        else
            dest = vector3(CJobCenter.job.Feraille.PedPos.x,CJobCenter.job.Feraille.PedPos.y,CJobCenter.job.Feraille.PedPos.z)

        end
        local distance = GetDistanceBetweenCoords(pos, dest, true)

        if not SetStateWaypoint then
            SetWaypoint()
        else
            if distance < 2 then
                interval = 1
                if state + 1 <= #CJobCenter.job.Feraille.state then
                    DrawMarker(2, CJobCenter.job.Feraille.state[state + 1].x,CJobCenter.job.Feraille.state[state + 1].y,CJobCenter.job.Feraille.state[state + 1].z, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.5, 0.5, 0.5, 245, 190, 112, 170, 0, 1, 2, 0, nil, nil, 0)
                    DrawScreenText("Appuyez sur [~g~E~s~] pour rammasez",1)

                    if IsControlJustPressed(1, 51) then
                        RequestAnimDict("random@domestic")
                        while not HasAnimDictLoaded("random@domestic")do 
                            Citizen.Wait(0) 
                        end
                        Citizen.Wait(100)
                        TaskStartScenarioInPlace(GetPlayerPed(-1), 'CODE_HUMAN_MEDIC_KNEEL', 0, false)
                        -- TaskPlayAnim(GetPlayerPed(-1), "random@domestic", "pickup_low", 2.0, 2.0, -1, 0, 0, false, false, false)
                        Citizen.Wait(3000)
                        ClearPedTasks(GetPlayerPed(-1))
                        Citizen.Wait(100)
                        TaskPlayAnim(GetPlayerPed(-1), "random@domestic", "pickup_low", 2.0, 2.0, -1, 0, 0, false, false, false)
                        Citizen.Wait(3000)
                        TriggerServerEvent("JobCenter:giveitem", "ferraille")
                        ClearPedTasks(GetPlayerPed(-1))
                        FutWaypoint()
                    end
                else
                    DrawScreenText("[~r~E~s~] pour mettre fin à votre journée de travail",1)

                    if IsControlJustPressed(1, 51) then
                        MenuFerailleur()
                        SetStateWaypoint = false
                        inWork = false
                        RemoveBlip(blip)
                    end
                end
                
                
            end
        end
        Wait(1.0)
    end 
end



Notif = function(msg)
    SetNotificationTextEntry('STRING')
    AddTextComponentSubstringPlayerName(msg)
    DrawNotification(false, true)
end

RegisterNetEvent("JobCenter:notif")
AddEventHandler('JobCenter:notif', function(msg)
    SetNotificationTextEntry('STRING')
    AddTextComponentSubstringPlayerName(msg)
    DrawNotification(false, true)
end)

DrawScreenText = function(msg, time)
    ClearPrints()
    BeginTextCommandPrint('STRING')
    AddTextComponentSubstringPlayerName(msg)
    EndTextCommandPrint(time, 1)
end