ESX = nil

local PlayerData = {}


TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)


RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
     PlayerData = xPlayer
end)

RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)  
	PlayerData.job = job  
	Citizen.Wait(5000) 
end)

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(10)
    end
    while ESX.GetPlayerData().job == nil do
		Citizen.Wait(10)
    end
    if ESX.IsPlayerLoaded() then

		ESX.PlayerData = ESX.GetPlayerData()

    end
end)


RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
	ESX.PlayerData = xPlayer
end)


RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)
	ESX.PlayerData.job = job
end)

RegisterNetEvent('esx:setJob2')
AddEventHandler('esx:setJob2', function(job2)
    ESX.PlayerData.job2 = job2
end)

local Permis 

function MenuJobCenter()
    local MenuJobCenter = RageUI.CreateMenu("~b~Job Center", "~b~Emploi Interimaire")
    MenuJobCenter:SetRectangleBanner(0, 0, 0)

    
    RageUI.Visible(MenuJobCenter, not RageUI.Visible(MenuJobCenter))
    while MenuJobCenter do
        Citizen.Wait(0)
        RageUI.IsVisible(MenuJobCenter, true, false, true, function()
            --RageUI.Separator("")
            RageUI.Separator("~y~↓ Nos Jobs ~y~↓")

            ESX.TriggerServerCallback("JobCenter:getLicencesPlayer", function(pass) 
                Permis = pass
            end)
                
                for k,v in pairs(CJobCenter.job.ListingJob) do
                    local PDC 
                    if v.permis == true then
                        PDC = "~g~Obligatoire !"
                    elseif v.permis == false then
                        PDC = "~o~Pas Obligatoire !"
                    end
                    -- print(k, json.encode(v))
                    RageUI.ButtonWithStyle(v.label, "Permis de conduire : "..PDC, {RightLabel = "→"}, true, function(Hovered,Active,Selected)
                        if (Selected) then
                            -- print(Permis)
                            if v.permis == true then
                                if Permis == true then
                                    JobSelect(v.value)
                                    RageUI.CloseAll()
                                elseif Permis == false then
                                    RageUI.Popup{
                                    	message = "~y~[~b~Job Center~y~]\n~b~Le permis est ~r~Obligatoire~b~ pour ce job !"
                                    }
                                    RageUI.CloseAll()
                                end
                            else
                                JobSelect(v.value)
                                RageUI.CloseAll()
                            end
                        end
                    end)
                end

            -- end)

            end, function() 
            end)

        if not RageUI.Visible(MenuJobCenter) then
            MenuJobCenter = RMenu:DeleteType("MenuJobCenter", true)
        end
    end
end

local gps = false

JobSelect = function(value)
	local playerPed = PlayerPedId()
	for k,v in pairs(CJobCenter.job) do
		-- print(k,json.encode(v))
		if value == k then
			-- print("job : "..value)

			DestinationBlip = AddBlipForCoord(CJobCenter.job[value].posped.boss.x, CJobCenter.job[value].posped.boss.y, CJobCenter.job[value].posped.boss.z)

			BeginTextCommandSetBlipName('STRING')
			AddTextComponentSubstringPlayerName('Destination')
			EndTextCommandSetBlipName(blip)
			SetBlipRoute(DestinationBlip, true)
			SetBlipAsFriendly(playerPed, true)
			SetBlipColour(playerPed, 2)
			gps = true
			DeleteBlip(DestinationBlip, value)
		else
			-- print("job introuvable")
		end
	end
end

DeleteBlip = function(DestinationBlip, value)
	while gps do
		local Timer = 500
        local joueurs = GetEntityCoords(GetPlayerPed(-1), false)
        local distJobCenter = Vdist(joueurs.x, joueurs.y, joueurs.z, CJobCenter.job[value].posped.boss.x, CJobCenter.job[value].posped.boss.y, CJobCenter.job[value].posped.boss.z)
        if distJobCenter <= 5.0 then
			RemoveBlip(DestinationBlip)
			gps = false
		end
		Citizen.Wait(Timer) 
	end
end

--------------------------------------------------------------------
Citizen.CreateThread(function()
    while true do
        local Timer = 500
        local joueurs = GetEntityCoords(GetPlayerPed(-1), false)
        local distJobCenter = Vdist(joueurs.x, joueurs.y, joueurs.z, CJobCenter.job.Acceuil.Markeracceuil.x, CJobCenter.job.Acceuil.Markeracceuil.y, CJobCenter.job.Acceuil.Markeracceuil.z)
        if distJobCenter <= 5.0 and CJobCenter.jeveuxmarker then
            Timer = 5
            DrawMarker(20, CJobCenter.job.Acceuil.Markeracceuil.x, CJobCenter.job.Acceuil.Markeracceuil.y, CJobCenter.job.Acceuil.Markeracceuil.z-1, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.3, 0.3, 0.3, 255, 0, 0, 255, 0, 1, 2, 0, nil, nil, 0)
            if distJobCenter <= 1.0 then
                Timer = 0
                RageUI.Text({ message = "~r~[E]~s~ pour parler  l'hotesse d'acceuil", time_display = 1 })
                if IsControlJustPressed(1,51) then
                    MenuJobCenter()
                    RageUI.CloseAll()
                end   
            end
        end 
        Citizen.Wait(Timer)   
    end
end)

Citizen.CreateThread(function()
	if CJobCenter.jeveuxblips then
        local blip = AddBlipForCoord(CJobCenter.job.Acceuil.pedacceuil.x, CJobCenter.job.Acceuil.pedacceuil.y, CJobCenter.job.Acceuil.pedacceuil.z)

        SetBlipSprite (blip, 682)
        SetBlipDisplay(blip, 4)
        SetBlipScale  (blip, 1.0)
        SetBlipColour (blip, 84)
        SetBlipAsShortRange(blip, true)

        BeginTextCommandSetBlipName('STRING')
        AddTextComponentSubstringPlayerName('~b~Job Center')
        EndTextCommandSetBlipName(blip)
	end
end)

Citizen.CreateThread(function()
    local hash = GetHashKey("cs_tanisha")
    while not HasModelLoaded(hash) do
        RequestModel(hash)
        Wait(20)
    end
    pedacceuilppa = CreatePed("PED_TYPE_CIVFEMALE", "cs_tanisha", CJobCenter.job.Acceuil.pedacceuil.x, CJobCenter.job.Acceuil.pedacceuil.y, CJobCenter.job.Acceuil.pedacceuil.z-1, CJobCenter.job.Acceuil.pedacceuil.h, false, true)
    SetBlockingOfNonTemporaryEvents(pedacceuilppa, true)
    FreezeEntityPosition(pedacceuilppa, true)
    SetEntityInvincible(pedacceuilppa, true)
    TaskStartScenarioInPlace(pedacceuilppa, 'WORLD_HUMAN_CLIPBOARD', 0, false)
end)

-- RegisterCommand("clearA", function()
--     ClearArea(-284.425, -934.451, 32.263, 10, true, false, false, false)
--     CLEAR_AREA_OF_PEDS(-284.425, -934.451, 32.263, 30, 1)
-- end)

Citizen.CreateThread(function()
    while (true) do
		ClearAreaOfPeds(-284.425, -934.451, 31.263, 50.0, 1)
        ClearAreaOfVehicles(-284.425, -934.451, 31.263, 80.0, false, false, false, false, false);
        Citizen.Wait(0)
    end
end)