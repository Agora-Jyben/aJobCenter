ESX = nil

local PlayerData = {}


TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)


RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
     PlayerData = xPlayer
end)

RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)  
	PlayerData.job = job  
	Citizen.Wait(5000) 
end)

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(10)
    end
    while ESX.GetPlayerData().job == nil do
		Citizen.Wait(10)
    end
    if ESX.IsPlayerLoaded() then

		ESX.PlayerData = ESX.GetPlayerData()

    end
end)


RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
	ESX.PlayerData = xPlayer
end)


RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)
	ESX.PlayerData.job = job
end)

RegisterNetEvent('esx:setJob2')
AddEventHandler('esx:setJob2', function(job2)
    ESX.PlayerData.job2 = job2
end)

local VetLivreur = false
local OnJobLivreur = false
local pblips = 0
local numliv = 0
local blipactif = false
local pLiv

MenuBossLivreur = function()
    local MenuBossLivreur = RageUI.CreateMenu("~g~Centre de livraison", "~b~Emploi Interimaire")
    MenuBossLivreur:SetRectangleBanner(0, 0, 0)

    
    RageUI.Visible(MenuBossLivreur, not RageUI.Visible(MenuBossLivreur))
    while MenuBossLivreur do
        Citizen.Wait(0)
        RageUI.IsVisible(MenuBossLivreur, true, false, true, function()
            --RageUI.Separator("")

            ESX.TriggerServerCallback("JobCenter:getLicencesPlayer", function(pass) 
                pLiv = pass
            end)

            if pLiv == true then
                RageUI.Separator("~y~↓ ~p~Le Vestiaire ~y~↓")

                if VetLivreur == false then
                    RageUI.ButtonWithStyle("Prendre la tenue de ~o~service", nil, {RightLabel = "→"}, true, function(Hovered,Active,Selected)
                        if (Selected) then
                            UniformLivreur()
                        end
                    end)
                elseif VetLivreur == true then
                    RageUI.ButtonWithStyle("Reprendre sa tenue ~g~Civil", nil, {RightLabel = "→"}, true, function(Hovered,Active,Selected)
                        if (Selected) then
                            Tcivil()
                        end
                    end)
                end

                RageUI.Separator("~y~↓ Le Job ~y~↓")

                if OnJobLivreur == true then
                    RageUI.ButtonWithStyle("~r~Arreter~s~ son service", nil, {RightLabel = "→"}, true, function(Hovered,Active,Selected)
                        if (Selected) then
                            StopLivreurJob()
                            RageUI.Popup{
                                message = "Vous venez de terminer votre journée !"
                            }
                            OnJobLivreur = false
                            pblips = 0
                            numliv = 0
                        end
                    end)
                elseif OnJobLivreur == false then
                    RageUI.ButtonWithStyle("~g~Prendre~s~ son service", nil, {RightLabel = "→"}, true, function(Hovered,Active,Selected)
                        if (Selected) then
                            TriggerServerEvent("JobCenterLiv:giveitem", "livcommand")
                            SpawnCTrie()
                            JobLivreur()
                            OnJobLivreur = true
                            RageUI.CloseAll()
                        end
                    end)
                end

            elseif pLiv == false then
                RageUI.Popup{
					message = 'Vous devez avoir le permis de conduire pour ce job !'
				}
				RageUI.CloseAll()
            end

            end, function() 
            end)

        if not RageUI.Visible(MenuBossLivreur) then
            MenuBossLivreur = RMenu:DeleteType("MenuBossLivreur", true)
        end
    end
end


JobLivreur = function()
    local playerPed = GetPlayerPed(-1)
    local plycrdjob = GetEntityCoords(GetPlayerPed(-1), false)

    for i=1,#CJobCenter.job.livreur.posliv, 1 do
        numliv = i
        
    end
    if pblips < numliv then
        if blipactif == false then
            blipactif = true
        end
        inLiv = true
        pblips = pblips+1
        CustomerBlip = AddBlipForCoord(CJobCenter.job.livreur.posliv[pblips].pointliv.x, CJobCenter.job.livreur.posliv[pblips].pointliv.y, CJobCenter.job.livreur.posliv[pblips].pointliv.z)
        SetBlipAsFriendly(CustomerBlip, true)
        SetBlipColour(CustomerBlip, 4)
        SetBlipCategory(CustomerBlip, 3)
        SetBlipRoute(CustomerBlip, true)
        activPoint()
    elseif pblips > numliv then
        if blipactif == false then
            blipactif = true
        end
        RageUI.Popup{
            message = "Vous avez terminez votre tournée, veuillez rentrer au dépot !"
        }
        CustomerBlip = AddBlipForCoord(CJobCenter.job.livreur.DelVeh.x,CJobCenter.job.livreur.DelVeh.y,CJobCenter.job.livreur.DelVeh.z)
        SetBlipAsFriendly(CustomerBlip, true)
        SetBlipColour(CustomerBlip, 4)
        SetBlipCategory(CustomerBlip, 3)
        SetBlipRoute(CustomerBlip, true)
        inLiv = false
    end
end

activPoint = function()
    while inLiv do 
        local interval = 500
        local pos = GetEntityCoords(PlayerPedId())
        if pblips <= numliv  then
            dest = vector3(CJobCenter.job.livreur.posliv[pblips].pointliv.x,CJobCenter.job.livreur.posliv[pblips].pointliv.y,CJobCenter.job.livreur.posliv[pblips].pointliv.z)

            local distance = GetDistanceBetweenCoords(pos, dest, true)

            if distance < 2 then
                interval = 1
                DrawMarker(2, CJobCenter.job.livreur.posliv[pblips].pointliv.x,CJobCenter.job.livreur.posliv[pblips].pointliv.y,CJobCenter.job.livreur.posliv[pblips].pointliv.z, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.5, 0.5, 0.5, 245, 190, 112, 170, 0, 1, 2, 0, nil, nil, 0)
                DrawScreenText("Appuyez sur [~g~E~s~] pour donner la commande",1)

                if IsControlJustPressed(1, 51) then
                    print("livraison faite pour la numéros "..pblips)
                    RemoveBlip(CustomerBlip)
                    TriggerServerEvent("JobCenter:venteitemliv")
                    inLiv = false
                    TriggerEvent("aJobCenter:livsuivante")
                    
                end
            end
        else
            JobLivreur()
        end
        
        Wait(1.0)
    end 
end

LivSuivante = function()
    if inLiv == false then
        inLiv = true
        if pblips < numliv then
            pblips = pblips+1
            CustomerBlip = AddBlipForCoord(CJobCenter.job.livreur.posliv[pblips].pointliv.x, CJobCenter.job.livreur.posliv[pblips].pointliv.y, CJobCenter.job.livreur.posliv[pblips].pointliv.z)
            SetBlipAsFriendly(CustomerBlip, true)
            SetBlipColour(CustomerBlip, 4)
            SetBlipCategory(CustomerBlip, 3)
            SetBlipRoute(CustomerBlip, true)
            activPoint()
            
        elseif pblips > numliv then
            RageUI.Popup{
                message = "Vous avez terminez votre tournée, veuillez rentrer au dépot !"
            }
            CustomerBlip = AddBlipForCoord(CJobCenter.job.livreur.DelVeh.x,CJobCenter.job.livreur.DelVeh.y,CJobCenter.job.livreur.DelVeh.z)
            SetBlipAsFriendly(CustomerBlip, true)
            SetBlipColour(CustomerBlip, 4)
            SetBlipCategory(CustomerBlip, 3)
            SetBlipRoute(CustomerBlip, true)
            inLiv = false
        end
    else
        -- print("Une erreurs c'est produite lors de la livraison suivante !")
    end
end

RegisterNetEvent("aJobCenter:livsuivante")
AddEventHandler("aJobCenter:livsuivante", function()
    
    if pblips <= numliv then
        inLiv = true
        pblips = pblips+1
        CustomerBlip = AddBlipForCoord(CJobCenter.job.livreur.posliv[pblips].pointliv.x, CJobCenter.job.livreur.posliv[pblips].pointliv.y, CJobCenter.job.livreur.posliv[pblips].pointliv.z)
        SetBlipAsFriendly(CustomerBlip, true)
        SetBlipColour(CustomerBlip, 2)
        SetBlipCategory(CustomerBlip, 3)
        SetBlipRoute(CustomerBlip, true)
    elseif pblips > numliv then
        RageUI.Popup{
            message = "Vous avez terminez votre tournée, veuillez rentrer au dépot !"
        }
        CustomerBlip = AddBlipForCoord(CJobCenter.job.livreur.DelVeh.x,CJobCenter.job.livreur.DelVeh.y,CJobCenter.job.livreur.DelVeh.z)
        SetBlipAsFriendly(CustomerBlip, true)
        SetBlipColour(CustomerBlip, 4)
        SetBlipCategory(CustomerBlip, 3)
        SetBlipRoute(CustomerBlip, true)
        inLiv = false
        pblips = 0
    end
end)

SpawnCTrie = function()
    local car = GetHashKey("mule4")

    RequestModel(car)
    while not HasModelLoaded(car) do
        RequestModel(car)
        Citizen.Wait(0)
    end

    local x, y, z = table.unpack(GetEntityCoords(GetPlayerPed(-1), false))
    local vehicle = CreateVehicle(car, CJobCenter.job.livreur.SpawnVeh.x, CJobCenter.job.livreur.SpawnVeh.y, CJobCenter.job.livreur.SpawnVeh.z, CJobCenter.job.livreur.SpawnVeh.h, true, false)
    SetEntityAsMissionEntity(vehicle, true, true)
    local plaque = "CDT"..math.random(1,9)
    SetVehicleNumberPlateText(vehicle, plaque) 
    SetPedIntoVehicle(GetPlayerPed(-1),vehicle,-1)
    SetVehicleMaxMods(vehicle)
end

UniformLivreur = function()
    TriggerEvent('skinchanger:getSkin', function(skin)
        local uniformObject
        if skin.sex == 0 then
            uniformObject = CJobCenter.job.livreur.tenue.male
            VetLivreur = true
        else
            uniformObject = CJobCenter.job.livreur.tenue.female
            VetLivreur = true
        end
        if uniformObject then
            TriggerEvent('skinchanger:loadClothes', skin, uniformObject)
        end
    end)
end

Tcivil = function()
    ESX.TriggerServerCallback('esx_skin:getPlayerSkin', function(skin, jobSkin)
        TriggerEvent('skinchanger:loadSkin', skin)
        VetLivreur = false
    end)
end



--------------------------------------------------------------------
Citizen.CreateThread(function()
    while true do
        local Timer = 500
        local joueurs = GetEntityCoords(GetPlayerPed(-1), false)
        local distJobCenter = Vdist(joueurs.x, joueurs.y, joueurs.z, CJobCenter.job.livreur.posped.boss.x, CJobCenter.job.livreur.posped.boss.y, CJobCenter.job.livreur.posped.boss.z)
        if distJobCenter <= 5.0 and CJobCenter.jeveuxmarker then
            Timer = 5
            DrawMarker(20, CJobCenter.job.livreur.posped.boss.x, CJobCenter.job.livreur.posped.boss.y, CJobCenter.job.livreur.posped.boss.z-1, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.3, 0.3, 0.3, 255, 0, 0, 255, 0, 1, 2, 0, nil, nil, 0)
            if distJobCenter <= 1.0 then
                Timer = 0
                RageUI.Text({ message = "~r~[E]~s~ pour parler chef de quai", time_display = 1 })
                if IsControlJustPressed(1,51) then
                    MenuBossLivreur()
                    RageUI.CloseAll()
                end   
            end
        end 

        local distdelCDT = Vdist(joueurs.x, joueurs.y, joueurs.z, CJobCenter.job.livreur.DelVeh.x, CJobCenter.job.livreur.DelVeh.y, CJobCenter.job.livreur.DelVeh.z)
        if distdelCDT <= 8.0 and CJobCenter.jeveuxmarker then
            Timer = 5
            DrawMarker(20, CJobCenter.job.livreur.DelVeh.x, CJobCenter.job.livreur.DelVeh.y, CJobCenter.job.livreur.DelVeh.z, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.3, 0.3, 0.3, 255, 0, 0, 255, 0, 1, 2, 0, nil, nil, 0)
            if distdelCDT <= 1.0 then
                Timer = 0
                RageUI.Text({ message = "~r~[E]~s~ pour rendre le véhicule de fonction", time_display = 1 })
                if IsControlJustPressed(1,51) then
                    local veh,dist4 = ESX.Game.GetClosestVehicle(playerCoords)
                    if dist4 < 4 then
                        DeleteEntity(veh)
                        RageUI.Popup{
                            message = "Le véhicule a bien était rendu à l'entreprise !"
                        }
                        if blipactif == true then
                            RemoveBlip(CustomerBlip)
                        end
                        RageUI.CloseAll()
                    end
                end   
            end
        end 
        Citizen.Wait(Timer)   
    end
end)


Citizen.CreateThread(function()
	if CJobCenter.jeveuxblips then
        local blip = AddBlipForCoord(CJobCenter.job.livreur.posped.boss.x, CJobCenter.job.livreur.posped.boss.y, CJobCenter.job.livreur.posped.boss.z)

        SetBlipSprite (blip, 637)
        SetBlipDisplay(blip, 4)
        SetBlipScale  (blip, 0.7)
        SetBlipColour (blip, 30)
        SetBlipAsShortRange(blip, true)

        BeginTextCommandSetBlipName('STRING')
        AddTextComponentSubstringPlayerName('~b~Centre de Livraison')
        EndTextCommandSetBlipName(blip)
	end
end)

Citizen.CreateThread(function()
    local hash = GetHashKey("cs_floyd")
    while not HasModelLoaded(hash) do
        RequestModel(hash)
        Wait(20)
    end
    pedlivreur = CreatePed("PED_TYPE_CIVFEMALE", "cs_floyd", CJobCenter.job.livreur.posped.ped.x, CJobCenter.job.livreur.posped.ped.y, CJobCenter.job.livreur.posped.ped.z-1, CJobCenter.job.livreur.posped.ped.h, false, true)
    SetBlockingOfNonTemporaryEvents(pedlivreur, true)
    FreezeEntityPosition(pedlivreur, true)
    SetEntityInvincible(pedlivreur, true)
    TaskStartScenarioInPlace(pedlivreur, 'WORLD_HUMAN_CLIPBOARD', 0, false)

    for k,v in pairs(CJobCenter.job.livreur.posliv) do
        -- print(k,json.encode(v))
        local hashliv = GetHashKey(CJobCenter.job.livreur.posliv[k].pedhash)
        while not HasModelLoaded(hashliv) do
            RequestModel(hashliv)
            Wait(20)
        end
        pedlivreur = CreatePed("PED_TYPE_CIVFEMALE", CJobCenter.job.livreur.posliv[k].pedhash, CJobCenter.job.livreur.posliv[k].pedliv.x, CJobCenter.job.livreur.posliv[k].pedliv.y, CJobCenter.job.livreur.posliv[k].pedliv.z-1, CJobCenter.job.livreur.posliv[k].pedliv.h, false, true)
        SetBlockingOfNonTemporaryEvents(pedlivreur, true)
        FreezeEntityPosition(pedlivreur, true)
        SetEntityInvincible(pedlivreur, true)
        TaskStartScenarioInPlace(pedlivreur, 'WORLD_HUMAN_CLIPBOARD', 0, false)
    end
end)